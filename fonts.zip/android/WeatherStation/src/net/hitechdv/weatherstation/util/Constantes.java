package net.hitechdv.weatherstation.util;

public class Constantes {
	
	public static final String SENDER_ID = "inserir_seu_numero_sender_id_aqui";
	
	public static final String TAG = "gcm";
}
