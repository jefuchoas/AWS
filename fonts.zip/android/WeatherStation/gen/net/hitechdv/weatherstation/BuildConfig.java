/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package net.hitechdv.weatherstation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}