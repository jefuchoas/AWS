package hitechdv.rest;

import com.google.gson.Gson;

import java.util.List;

import hitechdv.business.CellphoneBusiness;
import hitechdv.business.DadosDiariosBusiness;
import hitechdv.business.DadosMeteorologicosBusiness;
import hitechdv.business.DeviceBusiness;
import hitechdv.dao.DadosDiariosDao;
import hitechdv.dao.DadosMeteorologicosDao;
import hitechdv.model.DadosDiarios;
import hitechdv.model.DadosMeteorologicos;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;


@Path("/dados")
public class GerenciaDadosService {

	@GET
	@Path("/insert/{param}")
	public Response insertDados(@PathParam("param") String dados) {		
		String output = "";
		String s[] = null;		
		if ((dados != null) && (!dados.equals(""))) {
			s = dados.split("_");
			if ((s.length == 6) && (s[0].equals("senhaValidadora"))) {
				if ((new DadosMeteorologicosBusiness().insertDados(s)) && (new DadosDiariosBusiness().insertDados(s))) {
					output = "Dados inseridos com sucesso!";
				}
				else output = "Erro ao inserir os dados!";				
			} else output = "Dados insuficientes";					
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/inserir")
	public Response inserirDados(String dados) {		
		String output = "";
		String s[] = null;		
		if ((dados != null) && (!dados.equals(""))) {
			s = dados.split("_");
			if ((s.length == 6) && (s[0].equals("senhaValidadora"))) {
				if ((new DadosMeteorologicosBusiness().insertDados(s)) && (new DadosDiariosBusiness().insertDados(s))) {
					output = "Dados inseridos com sucesso!";
				}
				else output = "Erro ao inserir os dados!";				
			} else output = "Dados insuficientes";					
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/insertDevice")
	public Response inserirDispositivos(String dados) {		
		String output = "";
		if ((dados != null) && (!dados.equals(""))) {
			if (new DeviceBusiness().insertDevice(dados)) {
				output = "Dispositivo inserido com sucesso!";
			}
			else output = "Erro ao inserir o dispositivo!";					
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/removeDevice")
	public Response removerDispositivos(String dados) {		
		String output = "";
		if ((dados != null) && (!dados.equals(""))) {
			if (new DeviceBusiness().deleteDevice(dados)) {
				output = "Dispositivo removido com sucesso!";
			}
			else output = "Erro ao remover o dispositivo!";					
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/insertCellphone")
	public Response inserirCelulares(String fTelefone) {		
		String output = "";
		if ((fTelefone != null) && (!fTelefone.equals(""))) {
			if (new CellphoneBusiness().insertCellphone(fTelefone)) {
				output = "Celular inserido com sucesso!";
			}
			else {
				if (new CellphoneBusiness().existCellphone(fTelefone)) {
					output = "Celular ja existente na base de dados!";
				} else {
					output = "Erro ao inserir o celular!";
				}		        						
			}
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/removeCellphone")
	public Response removerCelulares(String fTelefone) {		
		String output = "";
		if ((fTelefone != null) && (!fTelefone.equals(""))) {
			if (new CellphoneBusiness().deleteCellphone(fTelefone)) {
				output = "Celular removido com sucesso!";
			}
			else {
				if (new CellphoneBusiness().existCellphone(fTelefone)) {
					output = "Erro ao remover o celular!";
				} else {
					output = "Celular inexistente na base de dados!";
				}		        						
			}
		} else output = "Dados invalidos";        
		return Response.status(200).entity(output).build();
	}

	@GET
	@Path("/dadosMeteorologicos/")
	@Produces("application/json")
	public String getDadosMeteorologicos() throws Exception {		
		DadosMeteorologicos dm = new DadosMeteorologicos();
		DadosMeteorologicosDao dmDao = new DadosMeteorologicosDao();
		dm = dmDao.search();		
		if(dm == null)
			throw new Exception("Dados não encontrados!");		
		return new Gson().toJson(dm);
	}

	@GET
	@Path("/dadosDiarios/")
	@Produces("application/json")
	public String getDadosDiarios() throws Exception {		
		DadosDiarios dd = new DadosDiarios();
		DadosDiariosDao ddDao = new DadosDiariosDao();
		dd = ddDao.search();		
		if(dd == null)
			throw new Exception("Dados não encontrados!");		
		return new Gson().toJson(dd);
	}

	@GET
	@Path("/threeDaysRain/")
	@Produces("application/json")
	public String getThreeDaysRain() throws Exception {		
		DadosMeteorologicosDao dmDao = new DadosMeteorologicosDao();
		float chuva = dmDao.searchThreeDaysRain();		
		return new Gson().toJson(chuva);
	}

	@GET
	@Path("/dadosMeteorologicosList/")
	@Produces("application/json")
	public String getDadosMeteorologicosList() throws Exception {		
		DadosMeteorologicosDao dmDao = new DadosMeteorologicosDao();
		List<DadosMeteorologicos> dadosList = dmDao.dadosMeteorologicosList();		
		return new Gson().toJson(dadosList);
	}

	@GET
	@Path("/dadosDiariosList/")
	@Produces("application/json")
	public String getDadosDiariosList() throws Exception {		
		DadosDiariosDao ddDao = new DadosDiariosDao();
		List<DadosDiarios> dadosList = ddDao.dadosDiariosList();		
		return new Gson().toJson(dadosList);
	}	
}