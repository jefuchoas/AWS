package hitechdv.business;

import hitechdv.dao.DadosMeteorologicosDao;
import hitechdv.model.DadosMeteorologicos;

import java.util.Calendar;
import java.util.TimeZone;

public class DadosMeteorologicosBusiness {
	
	public boolean insertDados (String s[]) {
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
		String data = c.get(Calendar.DAY_OF_MONTH) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.YEAR);				
		String hora = c.get(Calendar.HOUR_OF_DAY) + ":" + c.get(Calendar.MINUTE) + ":" + c.get(Calendar.SECOND);
		float rain = Float.parseFloat(s[2]);
		float temp = Float.parseFloat(s[3]);
		float humy = Float.parseFloat(s[5]);
		String origin = directionValidate (s[4]);
		double moisture = temp - (14.55 + 0.114 * temp) * (1 - (0.01 * humy)) - Math.pow((2.5 + 0.007 * temp) * (1 - (0.01 * humy)), 3) - (15.9 + 0.117 * temp) * Math.pow((1 - (0.01 * humy)), 14);                                                   
		DadosMeteorologicosDao dmDao = new DadosMeteorologicosDao();
		float dew = dmDao.arredondar((float)moisture, 2);
		String intensity = rainIntensity(dmDao.arredondar(rain, 2));
		DadosMeteorologicos dm = new DadosMeteorologicos(Float.parseFloat(s[1]), rain, Float.parseFloat(s[3]), s[4], data, hora, Float.parseFloat(s[5]), dew, origin, intensity);
		if (dmDao.save(dm)) {        	
			return true;
		} else return false;		
	}
	
	public String directionValidate (String direction) {
		String result = "";
		String[] dir = new String[] {"W","NW","N","SW","NE","S","SE","E"};
		String[] validate = new String[] {"Oeste", "Noroeste", "Norte", "Sudoeste", "Nordeste", "Sul", "Sudeste", "Leste"};
		for (int i = 0; i < dir.length; i++) {
			if (direction.equals(dir[i])) result = validate [i];
		}
		return result;
	}
	
	public String rainIntensity (float raingauge) {
		String result = "";
		if (raingauge == 0) result = "Nao chove agora";
		if (raingauge > 0 && raingauge <= 1.116) result = "Chuva fraca";
		if (raingauge > 1.116 && raingauge <= 1.324) result = "Chuva moderada a forte";
		if (raingauge > 1.324 && raingauge <= 1.832) result = "Chuva forte";
		if (raingauge > 1.832 && raingauge <= 2.84) result = "Chuva muito forte";
		if (raingauge > 2.84) result = "Chuva extremamente forte";
		return result;
	}
}
