package hitechdv.business;

import hitechdv.dao.DadosDiariosDao;
import hitechdv.model.DadosDiarios;

import java.util.Calendar;
import java.util.TimeZone;

public class DadosDiariosBusiness {
	
	public boolean insertDados (String s[]) {
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));				
		String data = c.get(Calendar.DAY_OF_MONTH) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.YEAR);				
		DadosDiarios dd = new DadosDiarios(Float.parseFloat(s[2]), Float.parseFloat(s[3]), data);
		if (new DadosDiariosDao().update(dd)) {
        	return true;
		} else return false;		
	}
}
