package hitechdv.business;

import hitechdv.dao.DevicesDao;
import hitechdv.model.Device;

public class DeviceBusiness {
	
	public boolean insertDevice (String s) {
		Device dev = new Device (s);
		if (new DevicesDao().insert(dev)) {
        	return true;
		} else return false;		
	}
	
	public boolean deleteDevice (String s) {
		Device dev = new Device (s);
		if (new DevicesDao().delete(dev)) {
        	return true;
		} else return false;		
	}
}
