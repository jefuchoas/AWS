package hitechdv.business;

import hitechdv.dao.CellphonesDao;
import hitechdv.model.Cellphone;

public class CellphoneBusiness {
	
	public boolean insertCellphone (String s) {
		String[] aux = s.split("=");
		s = aux[1];
		Cellphone cell = new Cellphone (s);
		if (new CellphonesDao().insert(cell)) {
        	return true;
		} else return false;		
	}
	
	public boolean deleteCellphone (String s) {
		String[] aux = s.split("=");
		s = aux[1];
		Cellphone cell = new Cellphone (s);
		if (new CellphonesDao().delete(cell)) {
        	return true;
		} else return false;		
	}
	
	public boolean existCellphone (String s) {
		String[] aux = s.split("=");
		s = aux[1];
		Cellphone cell = new Cellphone (s);
		if (new CellphonesDao().exist(cell)) {
        	return true;
		} else return false;		
	}
}
