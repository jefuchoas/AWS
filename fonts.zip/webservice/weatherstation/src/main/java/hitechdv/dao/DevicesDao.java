package hitechdv.dao;

import java.util.ArrayList;
import java.util.List;

import hitechdv.factory.MongoConnection;
import hitechdv.model.Device;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class DevicesDao{

	public DevicesDao() {		
	}

	public boolean insert(Device device) {
		boolean retorno = false;
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("devices");
		String deviceId = device.getDeviceId();
		deviceId = deviceId.replaceAll("\"","");
		BasicDBObject query = new BasicDBObject();
		query.put("deviceId", deviceId);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) {
		} else {
			DBObject obj = new BasicDBObject();
			obj.put("deviceId", deviceId);
			if (coll.save(obj) != null)  retorno = true;        	
		}
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}

	public List<Device> devicesList() {
		List<Device> devsList = new ArrayList<Device>();
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("devices");		
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", 1));
		if (cursor.hasNext()) {
			while(cursor.hasNext()) {
				Device dev = new Device();		    	
				BasicDBObject doc = (BasicDBObject) cursor.next();
				String deviceId = doc.getString("deviceId");
				dev.setDeviceId(deviceId);
				devsList.add(dev);
			}						
		} else {
			devsList = null;
		}		
		cursor.close();
		conn.getMongo().close();
		return devsList;
	}

	public boolean delete(Device device) {
		boolean retorno = false;
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("devices");
		String deviceId = device.getDeviceId();
		deviceId = deviceId.replaceAll("\"","");
		BasicDBObject query = new BasicDBObject();
		query.put("deviceId", deviceId);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) {
			DBObject obj = new BasicDBObject();
			obj.put("deviceId", deviceId);
			if (coll.remove(obj) != null)  retorno = true;
		}
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}

}
