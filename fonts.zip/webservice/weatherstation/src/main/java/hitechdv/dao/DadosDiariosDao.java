package hitechdv.dao;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import hitechdv.cloudmessage.EnviaMensagem;
import hitechdv.factory.MongoConnection;
import hitechdv.model.DadosDiarios;
import hitechdv.sms.EnviaSMS;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class DadosDiariosDao{

	public DadosDiariosDao() {		
	}

	public boolean update(DadosDiarios dados) {
		boolean retorno = false;
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("dados_diarios");
		String data = dados.getData();
		EnviaMensagem msg = new EnviaMensagem();
		float tempMedia = arredondar(dados.getTempMedia(), 2);
		float chAcumulada = arredondar(dados.getChAcumulada(), 2);
		DadosMeteorologicosDao dmDao = new DadosMeteorologicosDao();
		float chTresDias = 0;
		BasicDBObject query = new BasicDBObject();
		query.put("data", data);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) {
			BasicDBObject doc = (BasicDBObject) cursor.next();
			String min = doc.getString("minima").replace(",", ".");
			String med = doc.getString("media").replace(",", ".");
			String max = doc.getString("maxima").replace(",", ".");
			String ch = doc.getString("chAcumulada").replace(",", ".");
			float minima = arredondar(Float.parseFloat(min), 2);
			float atual = arredondar(Float.parseFloat(med), 2);
			float maxima = arredondar(Float.parseFloat(max), 2);    		
			float media = (atual + tempMedia) /2f;
			float chuva = arredondar(Float.parseFloat(ch), 2);
			if (maxima < tempMedia) maxima = tempMedia;
			if (minima > tempMedia) minima = tempMedia;
			chAcumulada += chuva;
			EnviaSMS sms = new EnviaSMS();	    	
			doc.append("minima", minima);
			doc.append("media", media);
			doc.append("maxima", maxima);
			doc.append("chAcumulada", chAcumulada);
			doc.append("data", data);
			coll.update(query, doc);
			chTresDias = arredondar(dmDao.searchThreeDaysRain(), 2);
			try {
				if (chTresDias >= 100) {
					msg.enviar("Alto risco de deslizamento de encostas!");
					sms.enviaLista("Alerta da Weather Station: Alto risco de deslizamento de encostas!");
				} else if (chTresDias >= 80) {
					msg.enviar("Risco de deslizamento de encostas!");
					sms.enviaLista("Alerta da Weather Station: Risco de deslizamento de encostas!");
				}				
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}	        
			retorno = true;
		} else {
			DBObject obj = new BasicDBObject();
			obj.put("minima", tempMedia);
			obj.put("media", tempMedia);
			obj.put("maxima", tempMedia);
			obj.put("chAcumulada", chAcumulada);
			obj.put("data", data);
			if (coll.save(obj) != null)  retorno = true;        	
		}
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}

	public DadosDiarios search() {		    	
		DadosDiarios dd = new DadosDiarios();	    	
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("dados_diarios");				
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", -1)).limit(1);		
		if (cursor.hasNext()) {
			BasicDBObject doc = (BasicDBObject) cursor.next();
			float minima = arredondar((float) doc.getDouble("minima"), 2);
			float media = arredondar((float) doc.getDouble("media"), 2);
			float maxima = arredondar((float) doc.getDouble("maxima"), 2);
			float chuva = arredondar((float) doc.getDouble("chAcumulada"), 2);
			String date = doc.getString("data");
			dd.setTempMaxima(maxima);
			dd.setTempMedia(media);
			dd.setTempMinima(minima);
			dd.setChAcumulada(chuva);
			dd.setData(date);
		} else {
			dd.setData("");
		}		
		cursor.close();
		conn.getMongo().close();		
		return dd;
	}
	
	public List<DadosDiarios> dadosDiariosList() {
		List<DadosDiarios> dadosList = new ArrayList<DadosDiarios>();
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("dados_diarios");		
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", -1)).limit(15);
		if (cursor.hasNext()) {
			while(cursor.hasNext()) {
				DadosDiarios dd = new DadosDiarios();		    	
				BasicDBObject doc = (BasicDBObject) cursor.next();
				float minima = arredondar((float) doc.getDouble("minima"), 2);
				float media = arredondar((float) doc.getDouble("media"), 2);
				float maxima = arredondar((float) doc.getDouble("maxima"), 2);
				float chuva = arredondar((float) doc.getDouble("chAcumulada"), 2);
				String date = doc.getString("data");
				dd.setTempMaxima(maxima);
				dd.setTempMedia(media);
				dd.setTempMinima(minima);
				dd.setChAcumulada(chuva);
				dd.setData(date);
				dadosList.add(dd);
			}						
		} else {
			dadosList = null;
		}		
		cursor.close();
		conn.getMongo().close();
		Collections.reverse(dadosList);
		return dadosList;
	}

	public float arredondar(float a, int x) {			
		float b, c, d;			
		d = (float)Math.pow(10, x);			
		b = (float)(a * d);	                
		c = (float)(Math.rint(b)) / d;	        
		return c;
	}
}
