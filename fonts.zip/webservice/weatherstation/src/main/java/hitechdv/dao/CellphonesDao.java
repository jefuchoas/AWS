package hitechdv.dao;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import hitechdv.factory.MongoConnection;
import hitechdv.model.Cellphone;
import hitechdv.sms.EnviaSMS;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class CellphonesDao{

	public CellphonesDao() {		
	}

	public boolean insert(Cellphone cellphone) {
		boolean retorno = false;
		EnviaSMS sms = new EnviaSMS();
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("cellphones");
		String cellNumber = cellphone.getCellNumber();
		cellNumber = cellNumber.replaceAll("\"","");
		BasicDBObject query = new BasicDBObject();
		query.put("cellNumber", cellNumber);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) {
		} else {
			DBObject obj = new BasicDBObject();
			obj.put("cellNumber", cellNumber);
			if (coll.save(obj) != null)  retorno = true;
			try {
	    		sms.enviaUnico("00000000000", "Novo celular cadastrado: " + cellNumber);
								
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}

	public List<Cellphone> cellphonesList() {
		List<Cellphone> cellList = new ArrayList<Cellphone>();
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("cellphones");		
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", 1));
		if (cursor.hasNext()) {
			while(cursor.hasNext()) {
				Cellphone cell = new Cellphone();		    	
				BasicDBObject doc = (BasicDBObject) cursor.next();
				String cellNumber = doc.getString("cellNumber");
				cell.setCellNumber(cellNumber);
				cellList.add(cell);
			}						
		} else {
			cellList = null;
		}		
		cursor.close();
		conn.getMongo().close();
		return cellList;
	}

	public boolean delete(Cellphone cellphone) {
		boolean retorno = false;
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("cellphones");
		String cellNumber = cellphone.getCellNumber();
		cellNumber = cellNumber.replaceAll("\"","");
		BasicDBObject query = new BasicDBObject();
		query.put("cellNumber", cellNumber);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) {
			DBObject obj = new BasicDBObject();
			obj.put("cellNumber", cellNumber);
			if (coll.remove(obj) != null)  retorno = true;
		}
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}
	
	public boolean exist(Cellphone cellphone) {
		boolean retorno = false;
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("cellphones");
		String cellNumber = cellphone.getCellNumber();
		cellNumber = cellNumber.replaceAll("\"","");
		BasicDBObject query = new BasicDBObject();
		query.put("cellNumber", cellNumber);
		DBCursor cursor = coll.find(query);
		if (cursor.hasNext()) retorno = true;
		cursor.close();
		conn.getMongo().close();		
		return retorno;
	}

}
