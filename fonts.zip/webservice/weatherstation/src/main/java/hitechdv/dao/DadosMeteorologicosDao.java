package hitechdv.dao;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import hitechdv.factory.MongoConnection;
import hitechdv.model.DadosMeteorologicos;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class DadosMeteorologicosDao{
	
	public DadosMeteorologicosDao() {		
        }
 
	public boolean save(DadosMeteorologicos dados) {
    	boolean retorno = false;
    	DB conn = MongoConnection.getConnection();
    	DBCollection coll = conn.getCollection("dados_meteorologicos");
    	DBObject obj = new BasicDBObject();
    	obj.put("anemometer", dados.getAnemometer());
    	obj.put("raingauge", dados.getRaingauge());
    	obj.put("temperature", dados.getTemperature());
    	obj.put("windvane", dados.getWindvane());
    	obj.put("humidity", dados.getHumidity());
    	obj.put("data", dados.getData());
    	obj.put("hora", dados.getHora());
    	obj.put("moisture", dados.getMoisture());
    	obj.put("origin", dados.getOrigin());
    	obj.put("intensity", dados.getIntensity());
    	if (coll.save(obj) != null)  retorno = true;
    	conn.getMongo().close();
    	return retorno;
    }
    
    public String insert(DadosMeteorologicos dados) {
    	DB conn = MongoConnection.getConnection();
    	DBCollection coll = conn.getCollection("dados_meteorologicos");
    	DBObject obj = new BasicDBObject();
    	obj.put("anemometer", dados.getAnemometer());
    	obj.put("raingauge", dados.getRaingauge());
    	obj.put("temperature", dados.getTemperature());
    	obj.put("windvane", dados.getWindvane());
    	obj.put("humidity", dados.getHumidity());
    	obj.put("data", dados.getData());
    	obj.put("hora", dados.getHora());
    	obj.put("moisture", dados.getMoisture());
    	obj.put("origin", dados.getOrigin());
    	obj.put("intensity", dados.getIntensity());
    	if (coll.save(obj) != null){
    		conn.getMongo().close();			
    		return "Dados inseridos no banco com sucesso!";
    	}else {
    		conn.getMongo().close();
    		return "Falha ao inserir os dados no banco!";
    	}    	
    }    
    
	public DadosMeteorologicos search() {    	
	    	DadosMeteorologicos dm = new DadosMeteorologicos();    	
	    	DB conn = MongoConnection.getConnection();
			DBCollection coll = conn.getCollection("dados_meteorologicos");		
			DBCursor cursor = coll.find().sort(new BasicDBObject("_id", -1)).limit(1);		
			if (cursor.hasNext()) {
				BasicDBObject doc = (BasicDBObject) cursor.next();
				String date = doc.getString("data");
				String hora = doc.getString("hora");
				float anemometer = arredondar((float) doc.getDouble("anemometer"), 2);
				float temperature = arredondar((float) doc.getDouble("temperature"), 2);
	    		float raingauge = arredondar((float) doc.getDouble("raingauge"), 2);
	    		float humidity = arredondar((float) doc.getDouble("humidity"), 2);
	    		String windvane = doc.getString("windvane");
	    		float moisture = arredondar((float) doc.getDouble("moisture"), 2);
	    		String origin = doc.getString("origin");
	    		String intensity = doc.getString("intensity");
	    		dm.setData(date);
	    		dm.setHora(hora);
	    		dm.setAnemometer(anemometer);
	    		dm.setRaingauge(raingauge);
	    		dm.setTemperature(temperature);
	    		dm.setWindvane(windvane);
	    		dm.setHumidity(humidity);
	    		dm.setMoisture(moisture);
	    		dm.setOrigin(origin);
	    		dm.setIntensity(intensity);
			} else {
				dm = null;
			}		
			cursor.close();
			conn.getMongo().close();    	
	        return dm;
    }
	
	public float searchThreeDaysRain() {	
		float ch = 0;	
		DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("dados_meteorologicos");	
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", -1)).limit(288);	
		if (cursor.hasNext()) {
			while(cursor.hasNext()) {
				BasicDBObject doc = (BasicDBObject) cursor.next();
				float chuva = arredondar((float) doc.getDouble("raingauge"), 2);
				ch += chuva;
				}		
		}		
		cursor.close();
		conn.getMongo().close();	
	    return ch;
    }
	
	public List<DadosMeteorologicos> dadosMeteorologicosList() {
		List<DadosMeteorologicos> dadosList = new ArrayList<DadosMeteorologicos>();
    	DB conn = MongoConnection.getConnection();
		DBCollection coll = conn.getCollection("dados_meteorologicos");		
		DBCursor cursor = coll.find().sort(new BasicDBObject("_id", -1)).limit(16);
		if (cursor.hasNext()) {
			while(cursor.hasNext()) {
				DadosMeteorologicos dm = new DadosMeteorologicos();		    	
				BasicDBObject doc = (BasicDBObject) cursor.next();
				String date = doc.getString("data");
				String hora = doc.getString("hora");
				float anemometer = arredondar((float) doc.getDouble("anemometer"), 2);
				float temperature = arredondar((float) doc.getDouble("temperature"), 2);
	    		float raingauge = arredondar((float) doc.getDouble("raingauge"), 2);
	    		float humidity = arredondar((float) doc.getDouble("humidity"), 2);
	    		String windvane = doc.getString("windvane");
	    		float moisture = arredondar((float) doc.getDouble("moisture"), 2);
	    		String origin = doc.getString("origin");
	    		String intensity = doc.getString("intensity");
	    		dm.setData(date);
	    		dm.setHora(hora);
	    		dm.setAnemometer(anemometer);
	    		dm.setRaingauge(raingauge);
	    		dm.setTemperature(temperature);
	    		dm.setWindvane(windvane);
	    		dm.setHumidity(humidity);
	    		dm.setMoisture(moisture);
	    		dm.setOrigin(origin);
	    		dm.setIntensity(intensity);
				dadosList.add(dm);
				}						
		} else {
			dadosList = null;
		}		
		cursor.close();
		conn.getMongo().close();
		Collections.reverse(dadosList);
        return dadosList;
	}	
	    
    public float arredondar(float a, int x) {			
		float b, c, d;			
		d = (float)Math.pow(10, x);			
		b = (float)(a * d);	                
        c = (float)(Math.rint(b)) / d;	        
        return c;
    }
}
