package hitechdv.factory;

import java.net.UnknownHostException;

import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.DB;

public class MongoConnection {
	private static Mongo mongo;
    private static DB mongoDB;
	
	static String host = System.getenv("OPENSHIFT_MONGODB_DB_HOST");
    static String sport = System.getenv("OPENSHIFT_MONGODB_DB_PORT");
    static String db = System.getenv("OPENSHIFT_APP_NAME");
    static String user = System.getenv("OPENSHIFT_MONGODB_DB_USERNAME");
    static String password = System.getenv("OPENSHIFT_MONGODB_DB_PASSWORD");
    static int port = Integer.decode(sport);
    
    public MongoConnection() {
    }
    
    public static DB getConnection() {
    	
    	if(db == null) db = "weatherstation";        
	    try {
	        mongo = new Mongo(host , port);
	    } catch (UnknownHostException e) {
	        throw new MongoException("Failed to access Mongo server", e);
	    }
	    mongoDB = mongo.getDB(db);
	    if(mongoDB.authenticate(user, password.toCharArray()) == false) {
	        throw new MongoException("Failed to authenticate against db: "+db);
	        }
	    
	    
	    return mongoDB;
    }
}
