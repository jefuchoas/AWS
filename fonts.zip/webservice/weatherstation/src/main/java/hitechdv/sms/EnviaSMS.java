package hitechdv.sms;

import hitechdv.dao.CellphonesDao;
import hitechdv.model.Cellphone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;

public class EnviaSMS {

	public void enviaLista (String mensagem) throws MalformedURLException, IOException {

		ArrayList<Cellphone> cellphones = new ArrayList<Cellphone>();
		CellphonesDao cellDao = new CellphonesDao();
		cellphones = (ArrayList<Cellphone>) cellDao.cellphonesList();

		if (cellphones.size() > 0) {
			for (int i=0; i < cellphones.size(); i++) {		

				try{
					String data = URLEncoder.encode( "usuario", "UTF-8" ) + "=" + URLEncoder.encode( "seu_usuario_aqui", "UTF-8" )
							+ "&" + URLEncoder.encode( "senha", "UTF-8" ) + "=" + URLEncoder.encode( "sua_senha_aqui", "UTF-8" )
							+ "&" + URLEncoder.encode( "numero", "UTF-8" ) + "=" + URLEncoder.encode( cellphones.get(i).getCellNumber(), "UTF-8" )
							+ "&" + URLEncoder.encode( "texto", "UTF-8" ) + "=" + URLEncoder.encode( mensagem, "UTF-8" );

					URL url = new URL( "endereco_do_servidor_de_sms" );
					URLConnection urlConnection = url.openConnection();

					urlConnection.setDoOutput(true);
					OutputStreamWriter outputWriter = new OutputStreamWriter(urlConnection.getOutputStream());
					outputWriter.write(data);
					outputWriter.flush();

					InputStreamReader inputReader = new InputStreamReader(urlConnection.getInputStream());
					@SuppressWarnings("unused")
					BufferedReader bufferedReader = new BufferedReader( inputReader ); 
				} catch (Exception e) {
					System.out.println( e.getMessage() );
				}
			}			
		}		
	}

	public void enviaUnico (String numero, String mensagem) throws MalformedURLException, IOException {
		try{
			String data = URLEncoder.encode( "usuario", "UTF-8" ) + "=" + URLEncoder.encode( "seu_usuario_aqui", "UTF-8" )
					+ "&" + URLEncoder.encode( "senha", "UTF-8" ) + "=" + URLEncoder.encode( "sua_senha_aqui", "UTF-8" )
					+ "&" + URLEncoder.encode( "numero", "UTF-8" ) + "=" + URLEncoder.encode( numero, "UTF-8" )
					+ "&" + URLEncoder.encode( "texto", "UTF-8" ) + "=" + URLEncoder.encode( mensagem, "UTF-8" );

			URL url = new URL( "endereco_do_servidor_de_sms" );
			URLConnection urlConnection = url.openConnection();

			urlConnection.setDoOutput(true);
			OutputStreamWriter outputWriter = new OutputStreamWriter(urlConnection.getOutputStream());
			outputWriter.write(data);
			outputWriter.flush();

			InputStreamReader inputReader = new InputStreamReader(urlConnection.getInputStream());
			@SuppressWarnings("unused")
			BufferedReader bufferedReader = new BufferedReader( inputReader ); 
		} catch (Exception e) {
			System.out.println( e.getMessage() );
		}		
	}
}