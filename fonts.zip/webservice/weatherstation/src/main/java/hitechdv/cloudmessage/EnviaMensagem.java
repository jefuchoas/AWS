package hitechdv.cloudmessage;

import hitechdv.dao.DevicesDao;
import hitechdv.model.Device;

import java.io.IOException;
import java.util.ArrayList;

import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Sender;

public class EnviaMensagem {


	private final String API_KEY = "digite_sua_api_key_aqui";

	public EnviaMensagem () {

	}

	public void enviar(String mensagem) {

		Sender sender = new Sender(API_KEY);

		ArrayList<String> devicesList = new ArrayList<String>();		
		ArrayList<Device> devices = new ArrayList<Device>();

		DevicesDao devDao = new DevicesDao();
		devices = (ArrayList<Device>) devDao.devicesList();

		if (devices.size() > 0) {

			for (int i=0; i < devices.size(); i++) {
				devicesList.add(devices.get(i).getDeviceId());
			}

			Message message = new Message.Builder().collapseKey("3").timeToLive(3).delayWhileIdle(true).addData("mensagem", mensagem).build();

			MulticastResult result = null;

			try {
				result = sender.send(message, devicesList, 5);
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (result != null)
				System.out.println(result.toString());			
		}		
	}
}
