function cadastrarForm() {
	var conteudo = document.getElementById("fTelefoneCadastro").value;
	conteudo = conteudo.replace("(", "");
	conteudo = conteudo.replace(")", "");
	conteudo = conteudo.replace("-", "");
	conteudo = conteudo.replace(" ", "");
	document.getElementById("fTelefoneCadastro").value = conteudo;
	document.getElementById("cadastroForm").submit();
}

function removerForm() {
	var conteudo = document.getElementById("fTelefoneRemocao").value;
	conteudo = conteudo.replace("(", "");
	conteudo = conteudo.replace(")", "");
	conteudo = conteudo.replace("-", "");
	conteudo = conteudo.replace(" ", "");
	document.getElementById("fTelefoneRemocao").value = conteudo;
	document.getElementById("remocaoForm").submit();
}

function limparCampoCadastro() {
    document.getElementById('fTelefoneCadastro').value="";
}

function limparCampoRemocao() {
   document.getElementById('fTelefoneRemocao').value="";
}


